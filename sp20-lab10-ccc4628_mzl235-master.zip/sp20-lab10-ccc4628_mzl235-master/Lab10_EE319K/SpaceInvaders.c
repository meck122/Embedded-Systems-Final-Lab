// SpaceInvaders.c
// Runs on LM4F120/TM4C123
// Jonathan Valvano and Daniel Valvano
// This is a starter project for the EE319K Lab 10

// Last Modified: 1/17/2020 
// http://www.spaceinvaders.de/
// sounds at http://www.classicgaming.cc/classics/spaceinvaders/sounds.php
// http://www.classicgaming.cc/classics/spaceinvaders/playguide.php
/* This example accompanies the books
   "Embedded Systems: Real Time Interfacing to Arm Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2019

   "Embedded Systems: Introduction to Arm Cortex M Microcontrollers",
   ISBN: 978-1469998749, Jonathan Valvano, copyright (c) 2019

 Copyright 2019 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */
// ******* Possible Hardware I/O connections*******************
// Slide pot pin 1 connected to ground
// Slide pot pin 2 connected to PD2/AIN5
// Slide pot pin 3 connected to +3.3V 
// fire button connected to PE0
// special weapon fire button connected to PE1
// 8*R resistor DAC bit 0 on PB0 (least significant bit)
// 4*R resistor DAC bit 1 on PB1
// 2*R resistor DAC bit 2 on PB2
// 1*R resistor DAC bit 3 on PB3 (most significant bit)
// LED on PB4
// LED on PB5

// Backlight (pin 10) connected to +3.3 V
// MISO (pin 9) unconnected
// SCK (pin 8) connected to PA2 (SSI0Clk)
// MOSI (pin 7) connected to PA5 (SSI0Tx)
// TFT_CS (pin 6) connected to PA3 (SSI0Fss)
// CARD_CS (pin 5) unconnected
// Data/Command (pin 4) connected to PA6 (GPIO), high for data, low for command
// RESET (pin 3) connected to PA7 (GPIO)
// VCC (pin 2) connected to +3.3 V
// Gnd (pin 1) connected to ground

#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
#include "ST7735.h"
#include "Print.h"
#include "Random.h"
#include "PLL.h"
#include "ADC.h"
#include "Images.h"
#include "Sound.h"
#include "Timer0.h"
#include "Timer1.h"

void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
void Delay100ms(uint32_t count); // time delay in 0.1 seconds

#define size 8

uint8_t alreadyShot = 0;
uint8_t ifShoot = 0;
uint8_t ADCStatus = 0;
uint32_t ADCMail = 0;
uint32_t Position;    // 32-bit fixed-point 0.001 cm
uint8_t Language = 0; //1-English 2-Spanish
uint8_t stage = 0;

void Systick_Init(){
	NVIC_ST_CTRL_R = 0;                   // disable SysTick during setup
  NVIC_ST_RELOAD_R = NVIC_ST_RELOAD_M;  // maximum reload value
  NVIC_ST_CURRENT_R = 0;                // any write to current clears it
                                        // enable SysTick with core clock
  NVIC_ST_CTRL_R = 0x7;
	
	NVIC_ST_RELOAD_R = 2666666;
	//DisableInterrupts();
}

void Button_Init(){
	SYSCTL_RCGCGPIO_R |= 0x10;	 	// Turn clock on PortE
	volatile uint32_t nop; 	
	nop++;
	GPIO_PORTE_DIR_R &= 0xFC;			// set PE0-1 inputs
	GPIO_PORTE_DEN_R |= 0x03;			// digital enable PE0-1
}

void PortF_Init(){
	// --UUU-- Code to initialize PF4 and PF0
  SYSCTL_RCGCGPIO_R |= 0x20;         // Turn clock on PortF 
  volatile uint32_t nop;
  nop++;                                                // Wait
  GPIO_PORTF_DIR_R |= 0X02;     // Set PF2 as output; LED
  GPIO_PORTF_DEN_R |= 0X02;            // digital enable PF2; LED
  GPIO_PORTF_LOCK_R = GPIO_LOCK_KEY;
  GPIO_PORTF_CR_R |= 0xFF;      // unlock portf since it is a special port
  GPIO_PORTF_DIR_R &= 0xEE;            // set PF4 as input
  GPIO_PORTF_DEN_R |= 0x11;        // digital enable PF4
  GPIO_PORTF_PUR_R |= 0x11;     // engage internal pull-up resistor for PF4
}

uint32_t PortF_Input(){
	return GPIO_PORTF_DATA_R;
}

uint32_t PortE_Input(){
	return GPIO_PORTE_DATA_R;
}

uint32_t Convert(uint32_t input){
	return 160*input/4096+13;
  //return 0; // replace this line with your Lab 8 solution
}

typedef enum {dead, alive} status_t;
struct sprite{
	int32_t x;
	int32_t y;
	int32_t vx, vy;
	const unsigned short *image;
	const unsigned short *black;
	status_t life;
	uint32_t w;
	uint32_t h;
	uint32_t needDraw;
	int32_t health;
};
typedef struct sprite sprite_t;

sprite_t Player;
sprite_t LaserArr[size];
sprite_t BossLaserArr[size*2];
sprite_t Boss[3];

int Flag;
int Anyalive;


void GameInit(void){
	Flag = 0;
	Player.x = 64;
	Player.y = 147;
	Player.vx = 0;
	Player.vy = 0;
	Player.image = heroship;
	Player.black = heroshipblack;
	Player.life = alive;
	Player.w = 20;
	Player.h = 16;
	Player.needDraw = 1;
	Player.health = 100;
	
	for(int i=0;i<size;i++){
		LaserArr[i].life = dead;
		LaserArr[i].image = Laser;
		LaserArr[i].black = BlackLaser;
		LaserArr[i].w = 6;
		LaserArr[i].h = 12;
		LaserArr[i].needDraw = 0;
	}
	
	Boss[0].x = 64;
	Boss[0].y = 22;
	Boss[0].vx = 1;
	Boss[0].vy = 0;
	Boss[0].image = boss0;
	Boss[0].black = boss0black;
	Boss[0].life = alive;
	Boss[0].w = 20;
	Boss[0].h = 14;
	Boss[0].needDraw = 1;
	Boss[0].health = 200;
	
	Boss[1].x = 64;
	Boss[1].y = 25;
	Boss[1].vx = 1;
	Boss[1].vy = 0;
	Boss[1].image = boss1;
	Boss[1].black = boss1black;
	Boss[1].life = alive;
	Boss[1].w = 22;
	Boss[1].h = 17;
	Boss[1].needDraw = 1;
	Boss[1].health = 400;
	
	Boss[2].x = 64;
	Boss[2].y = 35;
	Boss[2].vx = 1;
	Boss[2].vy = 0;
	Boss[2].image = boss2;
	Boss[2].black = boss2black;
	Boss[2].life = alive;
	Boss[2].w = 28;
	Boss[2].h = 24;
	Boss[2].needDraw = 1;
	Boss[2].health = 500;
	
	for(int i=0;i<size*2;i++){
		BossLaserArr[i].life = dead;
		BossLaserArr[i].image = BossLaser;
		BossLaserArr[i].black = BlackLaser;
		BossLaserArr[i].w = 6;
		BossLaserArr[i].h = 12;
		BossLaserArr[i].needDraw = 0;
	}
}

void GameMove(void){
	//Anyalive = 0;
	if(Player.life == alive){
		Player.needDraw = 1;
		Player.x += Player.vx;
		Player.y += Player.vy;
	}
	Position = Convert(ADCMail);
	int16_t PlayerSlide = Position - 45;
		if(PlayerSlide-1 > Player.x && Player.x < 110){
			Player.vx = 2;
		}else if (PlayerSlide+1 < Player.x && Player.x > 0){
			Player.vx = -2;
		}else {
			Player.vx = 0;
		}
		
	//laserstuff
	for(int i=0;i<size;i++){
		if(LaserArr[i].life == alive){
			LaserArr[i].needDraw = 1;
			if(LaserArr[i].y < 0){
				LaserArr[i].life = dead;
				//LaserArr[i].needDraw = 0;
			}else{
				LaserArr[i].y += LaserArr[i].vy;
			}
		}
	}	
	
	//bosslaserstuff
	for(int i=0;i<size*2;i++){
		if(BossLaserArr[i].life == alive){
			BossLaserArr[i].needDraw = 1;
			if(BossLaserArr[i].y > 160){
				BossLaserArr[i].life = dead;
				//BossLaserArr[i].needDraw = 0;
			}else{
				BossLaserArr[i].y += BossLaserArr[i].vy;
				BossLaserArr[i].x += BossLaserArr[i].vx;
			}
		}
	}	
	
	if(Boss[stage].life == alive){
		if(Boss[stage].x == 128-Boss[stage].w || Boss[stage].x == 0){
			Boss[stage].vx *= -1;
		}
		Boss[stage].x += Boss[stage].vx;
		Boss[stage].needDraw = 1;
	}
	
	//Anyalive = 1;
}


void GameDraw(void){
	
	for(int i=0; i<size; i++){
		if(LaserArr[i].needDraw){
			if(LaserArr[i].life == alive){
				ST7735_DrawBitmap(LaserArr[i].x, LaserArr[i].y, LaserArr[i].image,
				LaserArr[i].w, LaserArr[i].h);
			}else{
				ST7735_DrawBitmap(LaserArr[i].x, LaserArr[i].y, LaserArr[i].black,
				LaserArr[i].w, LaserArr[i].h);
			}
			LaserArr[i].needDraw = 0;
		}
	}
	
	if(Boss[stage].life == alive){
		for(int i=0; i<size*2; i++){
			if(BossLaserArr[i].needDraw){
				if(BossLaserArr[i].life == alive){
					ST7735_DrawBitmap(BossLaserArr[i].x, BossLaserArr[i].y, BossLaserArr[i].image,
					BossLaserArr[i].w, BossLaserArr[i].h);
				}else{
					ST7735_DrawBitmap(BossLaserArr[i].x, BossLaserArr[i].y, BossLaserArr[i].black,
					BossLaserArr[i].w, BossLaserArr[i].h);
				}
				BossLaserArr[i].needDraw = 0;
			}
		}
	}
	
	if(Boss[stage].needDraw){
		if(Boss[stage].life == alive){
			ST7735_DrawBitmap(Boss[stage].x, Boss[stage].y, Boss[stage].image,
			Boss[stage].w, Boss[stage].h);
		}else{
			ST7735_DrawBitmap(Boss[stage].x, Boss[stage].y, Boss[stage].black,
			Boss[stage].w, Boss[stage].h);
		}
		Boss[stage].needDraw = 0;
	}
	
	if(Player.needDraw){
		if(Player.life == alive){
			ST7735_DrawBitmap(Player.x, Player.y, Player.image,
			Player.w, Player.h);
			Player.needDraw = 0;
		}else{
			ST7735_DrawBitmap(Player.x, Player.y, Player.black,
			Player.w, Player.h);
		}
		Player.needDraw = 0;
	}
}


void SpawnLaser(void){
	int i = 0;
	for(i = 0; i<size; i++){
		if(LaserArr[i].life == dead){
			break;
		}
	}
	LaserArr[i].life = alive;
	LaserArr[i].x = Player.x+7;
	LaserArr[i].y = 140;
	LaserArr[i].vy = -2;
	LaserArr[i].vx = 0;
	LaserArr[i].needDraw = 1;
}

void Boss0Laser(void){
	static uint32_t count = 60;
	static uint32_t reset = 60;
	
	static uint8_t already1 = 0;
	static uint8_t already2 = 0;
	
	static uint8_t velocity = 1;
	
	if(Boss[stage].health <= 120 && Boss[stage].health > 60){
		reset = 40;
		if(!already1){
//			ST7735_SetCursor(17, 0);
//			ST7735_OutString("!");
			velocity = 2;
			already1 = 1;
		}
	}
	
	if(Boss[stage].health <= 60){
		reset = 20;
		if(!already2){
//			ST7735_SetCursor(17, 0);
//			ST7735_OutString("!!");
			velocity = 3;
			already2 = 1;
		}
	}
	
	count--;
	if(count <= 0){
		//shootlaser
		int i = 0;
		if(Boss[stage].life == alive){
			for(i = 0; i<size*2; i++){
				if(BossLaserArr[i].life == dead){
					break;
				}
			}
			BossLaserArr[i].life = alive;
			BossLaserArr[i].x = Boss[stage].x+(Boss[stage].w/2)-1;
			BossLaserArr[i].y = Boss[stage].y+(Boss[stage].h/4);
			BossLaserArr[i].vy = velocity;
			BossLaserArr[i].vx = 0;
			BossLaserArr[i].needDraw = 1;		
			count = reset;
		}
	}
}

void Boss1Laser(void){
	static uint32_t count = 60;
	static uint32_t reset = 60;
	
	//if(Boss[stage].health <= 80){
	//	reset = 25;
	//}
	static uint8_t already1 = 0;
	static uint8_t already2 = 0;
	static uint8_t already3 = 0;
	
	if(Boss[stage].health <= 300 && Boss[stage].health > 200){
		reset = 40;
		if(!already1){
//			ST7735_SetCursor(17, 0);
//			ST7735_OutString("!");
			already1 = 1;
		}
	}
	
	if(Boss[stage].health <= 200 && Boss[stage].health > 100){
		reset = 30;
		if(!already2){
//			ST7735_SetCursor(17, 0);
//			ST7735_OutString("!!");
			already2 = 1;
		}
	}
	
	if(Boss[stage].health <= 100){
		reset = 20;
		if(!already3){
//			ST7735_SetCursor(16, 0);
//			ST7735_OutString("!");
			already3 = 1;
		}
	}
	
	count--;
	if(count <= 0){
		//shootlaser
		int i = 0;
		if(Boss[stage].life == alive){
			for(i = 0; i<size*2; i++){
				if(BossLaserArr[i].life == dead){
					break;
				}
			}
			BossLaserArr[i].life = alive;
			BossLaserArr[i].x = Boss[stage].x+(Boss[stage].w/2)-1;
			BossLaserArr[i].y = Boss[stage].y+(Boss[stage].h/4);
			BossLaserArr[i].vy = 3;
			BossLaserArr[i].vx = 1;
			BossLaserArr[i].needDraw = 1;		
			
			for(i = 0; i<size*2; i++){
				if(BossLaserArr[i].life == dead){
					break;
				}
			}
			BossLaserArr[i].life = alive;
			BossLaserArr[i].x = Boss[stage].x+(Boss[stage].w/2)-1;
			BossLaserArr[i].y = Boss[stage].y+(Boss[stage].h/4);
			BossLaserArr[i].vy = 3;
			BossLaserArr[i].vx = -1;
			BossLaserArr[i].needDraw = 1;	
			
			count = reset;
		}
	}
}

void Boss2Laser(void){
	static uint32_t count = 20;
	static uint32_t reset = 20;
	
	//if(Boss[stage].health <= 80){
	//	reset = 25;
	//}
	
	static uint8_t already1 = 0;
	static uint8_t already2 = 0;
	static uint8_t already3 = 0;
	//static uint8_t already4 = 0;
	
	//Boss[stage].health = 200;
	
	if(Boss[stage].health <= 400 && Boss[stage].health > 300){
		reset = 30;
		if(!already1){
//			ST7735_SetCursor(17, 0);
//			ST7735_OutString("!");
			already1 = 1;
		}
	}
	
	if(Boss[stage].health <= 300 && Boss[stage].health >= 200){
		reset = 40;
		if(!already2){
//			ST7735_SetCursor(17, 0);
//			ST7735_OutString("!!");
			already2 = 1;
		}
	}
	
	if(Boss[stage].health <= 100){
		reset = 30;
		if(!already3){
//			ST7735_SetCursor(16, 0);
//			ST7735_OutString("!");
			already3 = 1;
		}
	}
	
	count--;
	if(count <= 0){
		//shootlaser
		int i = 0;
		if(Boss[stage].life == alive){
			
			if(already1 == 1){
				//right
				for(i = 0; i<size*2; i++){
					if(BossLaserArr[i].life == dead){
						break;
					}
				}
				
				BossLaserArr[i].life = alive;
				BossLaserArr[i].x = Boss[stage].x+(Boss[stage].w/2)-1;
				BossLaserArr[i].y = Boss[stage].y-(Boss[stage].h/2);
				BossLaserArr[i].vy = 3;
				BossLaserArr[i].vx = 1;
				BossLaserArr[i].needDraw = 1;		
			}
			
			if(already1 == 1){
				//left
				for(i = 0; i<size*2; i++){
					if(BossLaserArr[i].life == dead){
						break;
					}
				}
				BossLaserArr[i].life = alive;
				BossLaserArr[i].x = Boss[stage].x+(Boss[stage].w/2)-1;
				BossLaserArr[i].y = Boss[stage].y-(Boss[stage].h/2);
				BossLaserArr[i].vy = 3;
				BossLaserArr[i].vx = -1;
				BossLaserArr[i].needDraw = 1;	
			}
			
			if(already1 != 1 || already2 == 1 || already3 == 1){
				//middle
				for(i = 0; i<size*2; i++){
					if(BossLaserArr[i].life == dead){
						break;
					}
				}
				BossLaserArr[i].life = alive;
				BossLaserArr[i].x = Boss[stage].x+(Boss[stage].w/2)-1;
				BossLaserArr[i].y = Boss[stage].y-(Boss[stage].h/2);
				BossLaserArr[i].vy = 3;
				BossLaserArr[i].vx = 0;
				BossLaserArr[i].needDraw = 1;	
			}
			
//			//way left and way right
//			if(already3 == 1){
//				for(i = 0; i<size*2; i++){
//					if(BossLaserArr[i].life == dead){
//						break;
//					}
//				}
//				BossLaserArr[i].life = alive;
//				BossLaserArr[i].x = Boss[stage].x+(Boss[stage].w/2)-1;
//				BossLaserArr[i].y = Boss[stage].y-(Boss[stage].h/2);
//				BossLaserArr[i].vy = 2;
//				BossLaserArr[i].vx = -1;
//				BossLaserArr[i].needDraw = 1;

//				for(i = 0; i<size*2; i++){
//					if(BossLaserArr[i].life == dead){
//						break;
//					}
//				}
//				BossLaserArr[i].life = alive;
//				BossLaserArr[i].x = Boss[stage].x+(Boss[stage].w/2)-1;
//				BossLaserArr[i].y = Boss[stage].y-(Boss[stage].h/2);
//				BossLaserArr[i].vy = 2;
//				BossLaserArr[i].vx = 1;
//				BossLaserArr[i].needDraw = 1;					
//			}
			
			count = reset;
		}
			
	}
}

void CheckAlive(void){
	if(Boss[stage].health <= 0){
		Boss[stage].life = dead;
		ST7735_FillScreen(0x0000);   // set screen to black
		stage++;
		for(int i = 0; i < size; i++){
			LaserArr[i].life = dead;
			LaserArr[i].needDraw = 0;
		}
		for(int i = 0; i < size*2; i++){
			BossLaserArr[i].life = dead;
			BossLaserArr[i].needDraw = 0;
		}
		
		Player.health = 100;
		
		if(stage == 2){
			Player.health = 140;
		}
		
//		ST7735_SetCursor(0, 12);
//		ST7735_OutString("   ");
		
		Sound_Killed();
		
	}
	
}

void ClearScreen(void){
		ST7735_FillScreen(0x0000);   // set screen to black
	}

void CheckCollision(void){
	//checks player to boss
	for(int i=0; i<size; i++){
		if(LaserArr[i].life == alive){
			//check collision
			uint8_t bossMaxX = Boss[stage].x + Boss[stage].w;
			uint8_t bossMaxY = Boss[stage].y;
			uint8_t bossMinX = Boss[stage].x;
			uint8_t bossMinY = Boss[stage].y - Boss[stage].h;
			
			uint8_t laserMaxX = LaserArr[i].x + 4;
			uint8_t laserMaxY = LaserArr[i].y;
			uint8_t laserMinX = LaserArr[i].x;
			uint8_t laserMinY = LaserArr[i].y - 6;
			
			if((laserMaxX < bossMaxX) && (laserMaxX > bossMinX) && (laserMaxY < bossMaxY) && (laserMaxY > bossMinY)){ //XY
				Boss[stage].health -= 20;
				LaserArr[i].life = dead;
				Sound_Explosion();
			}else if((laserMaxX < bossMaxX) && (laserMaxX > bossMinX) && (laserMinY < bossMaxY) && (laserMinY > bossMinY)){ //Xy
				Boss[stage].health -= 20;
				LaserArr[i].life = dead;
				Sound_Explosion();
			}else if((laserMinX < bossMaxX) && (laserMinX > bossMinX) && (laserMaxY < bossMaxY) && (laserMaxY > bossMinY)){ //xY
				Boss[stage].health -= 20;
				LaserArr[i].life = dead;
				Sound_Explosion();
			}else if((laserMinX < bossMaxX) && (laserMinX > bossMinX) && (laserMinY < bossMaxY) && (laserMinY > bossMinY)){ //xy
				Boss[stage].health -= 20;
				LaserArr[i].life = dead;
				Sound_Explosion();
			}
		}
	}
	
	//checks boss to player
	for(int i=0; i<size*2; i++){
		if(BossLaserArr[i].life == alive){
			//check collision
			uint8_t playerMaxX = Player.x + Player.w;
			uint8_t playerMaxY = Player.y;
			uint8_t playerMinX = Player.x;
			uint8_t playerMinY = Player.y - Player.h;
			
			uint8_t laserMaxX = BossLaserArr[i].x + 4;
			uint8_t laserMaxY = BossLaserArr[i].y;
			uint8_t laserMinX = BossLaserArr[i].x;
			uint8_t laserMinY = BossLaserArr[i].y - 6;
			
			if((laserMaxX < playerMaxX) && (laserMaxX > playerMinX) && (laserMaxY < playerMaxY) && (laserMaxY > playerMinY)){ //XY
				Player.health -= 20;
				BossLaserArr[i].life = dead;
				Sound_Highpitch();
			}else if((laserMaxX < playerMaxX) && (laserMaxX > playerMinX) && (laserMinY < playerMaxY) && (laserMinY > playerMinY)){ //Xy
				Player.health -= 20;
				BossLaserArr[i].life = dead;
				Sound_Highpitch();
			}else if((laserMinX < playerMaxX) && (laserMinX > playerMinX) && (laserMaxY < playerMaxY) && (laserMaxY > playerMinY)){ //xY
				Player.health -= 20;
				BossLaserArr[i].life = dead;
				Sound_Highpitch();
			}else if((laserMinX < playerMaxX) && (laserMinX > playerMinX) && (laserMinY < playerMaxY) && (laserMinY > playerMinY)){ //xy
				Player.health -= 20;
				BossLaserArr[i].life = dead;
				Sound_Highpitch();
			}
		}
	}
}

void Pause(){
	uint32_t now1, last1;
	DisableInterrupts();
	
	if(Language == 1){
		ST7735_SetCursor(5, 7);
		ST7735_OutString("Game Paused");
	}else {
		ST7735_SetCursor(4, 7);
		ST7735_OutString("Juego Pausado");
	}
	
	while(1){
		now1 = PortE_Input() & 0x02;
		if((last1 == 0x00) && (now1 == 0x02)){
			//ClearScreen();
			break;
		}
		last1 = PortE_Input() & 0x02;
	}
	
	ST7735_FillScreen(0x0000);   // set screen to black
	
	ST7735_SetCursor(4, 7);
	ST7735_OutString("               ");
	EnableInterrupts();
}

uint32_t now0, last0 = 0x00;
uint32_t now1, last1 = 0x00;

void ButtonInput(void){
	//Button PE0
	now0 = PortE_Input() & 0x01;
	if((last0 == 0x00) && (now0 == 0x01)){
		ifShoot = 1;
		if(Language == 0){ //only runs at main menu
			Language = 1;
		}
	}
	last0 = PortE_Input() & 0x01;
	
	//Button PE1
	now1 = PortE_Input() & 0x02;
	if((last1 == 0x00) && (now1 == 0x02)){
		//ClearScreen();
		//Pause();
		if(Language == 0){ //only runs at main menu
			Language = 2;
		}else if (stage != 2){
			Pause();
		}
	}
	last1 = PortE_Input() & 0x02;
}


void EndGame(){
	if(stage > 2){
		if(Language == 1){
			ST7735_FillScreen(0x0000);   // set screen to black
			ST7735_SetCursor(1, 1);
			ST7735_OutString("You Win!");
			ST7735_SetCursor(1, 2);
			ST7735_OutString("Good");
			ST7735_SetCursor(1, 3);
			ST7735_OutString("Job!");
		}else{
			ST7735_FillScreen(0x0000);   // set screen to black
			ST7735_SetCursor(1, 1);
			ST7735_OutString("Tu Ganas!");
			ST7735_SetCursor(1, 2);
			ST7735_OutString("Buen Trabajo!");
		}
	}else if(Language == 1){
		ST7735_FillScreen(0x0000);   // set screen to black
		ST7735_SetCursor(1, 1);
		ST7735_OutString("GAME OVER");
		ST7735_SetCursor(1, 2);
		ST7735_OutString("Nice try,");
		ST7735_SetCursor(1, 3);
		ST7735_OutString("Earthling!");
	}else{
		ST7735_FillScreen(0x0000);   // set screen to black
		ST7735_SetCursor(1, 1);
		ST7735_OutString("Juego Terminado");
		ST7735_SetCursor(1, 2);
		//ST7735_OutString("Nice try,");
		ST7735_SetCursor(1, 3);
		//ST7735_OutString("Earthling!");
	}
}

int main(void){
	ST7735_InitR(INITR_REDTAB);
	DisableInterrupts();
	
	Output_Init();
	GameInit();
	ST7735_FillScreen(0x0000);
	
	//Timer1_Init(&GameTask, 80000000/30);
	
	PLL_Init(Bus80MHz);
  ADC_Init();     	// turn on ADC, set channel to 5
	ADC0_SAC_R = 4;
	PortF_Init();
	Button_Init();
	Systick_Init();
	Sound_Init();
	
	ST7735_FillScreen(0x0000);   // set screen to black
	ST7735_SetCursor(1, 1);
	ST7735_OutString("Boss Barrage");
	ST7735_SetCursor(1, 2);
	ST7735_OutString("Press a Language");
	ST7735_SetCursor(1, 3);
	ST7735_OutString("to Play.");
	ST7735_SetCursor(1, 4);
	ST7735_OutString("Button 1: English");
	ST7735_SetCursor(1, 5);
	ST7735_OutString("Button 2: Espanol");
	
	while(Language == 0){
		ButtonInput();
		ifShoot = 0;
	}
	
	ST7735_FillScreen(0x0000);   // set screen to black
	
	
  EnableInterrupts();
	
	//ST7735_DrawBitmap(20,9, SmallEnemy10pointB, 16,10);
	//ST7735_DrawBitmap(60, 100, Laser, 6,10);
	
	uint8_t count = 30;
	
  while(Player.health != 0){
		while(Flag==0){};
		Flag=0;
		GameDraw();
		
		if(Language == 1){
			ST7735_SetCursor(0,15);
			ST7735_OutString("Player Health: ");
			if(Player.health < 100){
				ST7735_SetCursor(17,15);
				ST7735_OutString(" ");
			}
			ST7735_SetCursor(15, 15);
			LCD_OutDec(Player.health);
			
			ST7735_SetCursor(0,0);
			ST7735_OutString("Boss Health: ");
			if(Boss[stage].health < 100){
				ST7735_SetCursor(15,0);
				ST7735_OutString(" ");
			}
			ST7735_SetCursor(13, 0);
			LCD_OutDec(Boss[stage].health);
		}else{
			ST7735_SetCursor(0,15);
			ST7735_OutString("Jugador: ");
			if(Player.health < 100){
				ST7735_SetCursor(11,15);
				ST7735_OutString(" ");
			}
			ST7735_SetCursor(9, 15);
			LCD_OutDec(Player.health);
			
			ST7735_SetCursor(0,0);
			ST7735_OutString("Jefe: ");
			if(Boss[stage].health < 100){
				ST7735_SetCursor(8,0);
				ST7735_OutString(" ");
			}
			ST7735_SetCursor(6, 0);
			LCD_OutDec(Boss[stage].health);
		}
			
		if(stage > 2){
			break;
		}			
			
			
//			ST7735_SetCursor(1, 1);
//			ST7735_OutString("GAME OVER");
//			ST7735_SetCursor(1, 2);
//			ST7735_OutString("Nice try,");
//			ST7735_SetCursor(1, 3);
//			ST7735_OutString("Earthling!");
			//LCD_OutDec(ADCMail);
		
		
		if(count != 0){
				count--;
			}
		
		if(ifShoot && count == 0){
			Sound_Shoot();
			ifShoot = 0;
			SpawnLaser();
			count = 30;
		}
  }
	
	DisableInterrupts();
	
	
	EndGame();
	
}

void SlidePotInput(void){
	ADCMail = ADC_In();      // Sample ADC
  ADCStatus = 1;           // Synchronize with other threads
}

void GameTask(void){
	GameMove();
	ButtonInput();
	SlidePotInput();
	CheckCollision();
	CheckAlive();
	if(stage == 0){
		Boss0Laser();
	}else if (stage == 1){
		Boss1Laser();
	}else if (stage == 2){
		Boss2Laser();
	}
	Flag = 1;
}




//int mainSound(void){
//	uint32_t last, now;
//	DisableInterrupts();
//	PLL_Init(Bus80MHz);
//	PortF_Init();
//	Sound_Init();
//	EnableInterrupts();
//	last = PortF_Input();
//	while(1){
//		now = PortF_Input();
//		if((last == 0x11)&&(now != 0x11)){
//			Sound_Shoot();
//			do{
//				now = PortF_Input();
//			}while(now != 0x11);
//		}
//	}
//}





void SysTick_Handler(void){
  GPIO_PORTF_DATA_R ^= 0x02; // toggle PF1
	GameTask();
}

// You can't use this timer, it is here for starter code only 
// you must use interrupts to perform delays
void Delay100ms(uint32_t count){uint32_t volatile time;
  while(count>0){
    time = 727240;  // 0.1sec at 80 MHz
    while(time){
	  	time--;
    }
    count--;
  }
}
